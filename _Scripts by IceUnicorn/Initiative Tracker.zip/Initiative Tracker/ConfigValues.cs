public static class ConfigValues
{
	public static string Name = "";
}
ConfigValues.Name = Config.Name;