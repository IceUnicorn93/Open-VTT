public class DefaultPlaylistData
{
	public string Name;
	public string URL;
}