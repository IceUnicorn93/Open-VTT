// Feel free to modify this code! :)
StreamDeckStatics.ActionList.Add(("ActionName0", "Spotify.Action0", StreamDeck.btnRepeatContextAction));
StreamDeckStatics.ActionList.Add(("ActionName1", "Spotify.Action1", StreamDeck.btnNextAction));
StreamDeckStatics.ActionList.Add(("ActionName2", "Spotify.Action2", StreamDeck.btnRepeatOffAction));
StreamDeckStatics.ActionList.Add(("ActionName3", "Spotify.Action3", StreamDeck.btnShuffleOffAction));
StreamDeckStatics.ActionList.Add(("ActionName4", "Spotify.Action4", StreamDeck.btnShuffleOnAction));
StreamDeckStatics.ActionList.Add(("ActionName5", "Spotify.Action5", StreamDeck.btnPlayAction));
StreamDeckStatics.ActionList.Add(("ActionName6", "Spotify.Action6", StreamDeck.btnPreviousAction));
StreamDeckStatics.ActionList.Add(("ActionName7", "Spotify.Action7", StreamDeck.btnRepeatSongAction));
StreamDeckStatics.ActionList.Add(("ActionName8", "Spotify.Action8", StreamDeck.btnStopAction));