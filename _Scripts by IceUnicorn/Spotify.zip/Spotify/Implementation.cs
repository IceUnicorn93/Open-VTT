Page.Text = Config.Name;

var main = new Main(null);
main.Dock = DockStyle.Fill;
Page.Controls.Add(main);
